import boto3
import pandas as pd
from io import BytesIO

def lambda_handler(event, context):
    # Get the S3 bucket and file key from the event
    s3_bucket = event['Records'][0]['s3']['bucket']['name']
    file_key = event['Records'][0]['s3']['object']['key']
    
    # Initialize S3 and retrieve the CSV file
    s3 = boto3.client('s3')
    
    # Get the CSV content
    response = s3.get_object(Bucket=s3_bucket, Key=file_key)
    csv_content = response['Body'].read().decode('utf-8', errors='replace')
    
    # Convert CSV to DataFrame
    csv_data = BytesIO(csv_content.encode('utf-8'))
    df = pd.read_csv(csv_data)
    
    # Convert DataFrame to XLSX
    xlsx_data = BytesIO()
    with pd.ExcelWriter(xlsx_data, engine='xlsxwriter') as writer:
        df.to_excel(writer, sheet_name='Sheet1', index=False)
    
    # Upload XLSX file to S3
    xlsx_key = file_key.replace('.csv', '.xlsx')
    s3.put_object(Bucket=s3_bucket, Key=xlsx_key, Body=xlsx_data.getvalue())
    
    return {
        'statusCode': 200,
        'body': 'CSV file converted to XLSX'
    }